<!DOCTYPE html>
<html lang="en">

<head>
    
    <title>Home Page - Online Birth Certificate System</title>


   
    <link href="style.css" rel="stylesheet">

    
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    
    <div id="preloader">
        <div class="loader">
            <span class="inner1"></span>
            <span class="inner2"></span>
            <span class="inner3"></span>
        </div>
    </div>

   

    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg align-items-center">
                        <a class="navbar-brand" href="index.php"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#fancyNav" aria-controls="fancyNav" aria-expanded="false" aria-label="Toggle navigation"><span class="ti-menu"></span></button>
                        <div class="collapse navbar-collapse" id="fancyNav">
                            <ul class="navbar-nav ml-auto">
                                
                             
                                <li class="nav-item">
                                
                                    <a class="nav-link" href="user/login.php">USER</a>
                                </li>
                                      <li class="nav-item">
                                    <a class="nav-link" href="user/search.php">VERIFY CERTIFICATE</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="admin/login.php">ADMIN</a>
                                </li>
                             
                            </ul>
                         
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
  

   
    <div class="fancy-hero-area bg-img bg-overlay animated-img" style="background-image: url(img/img4.png);">;  
       
</div>
    

  

  
    <footer class="fancy-footer-area fancy-bg-dark">
      
        <div class="footer-copywrite-area">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="copywrite-content h-100 d-flex align-items-center justify-content-between">
                            
                            <div class="copywrite-text">
                                <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
 Online Birth Certificate System 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                            </div>
                            <!-- Footer Nav -->
                            <div class="footer-nav">
                                <nav>
                                    <ul>
                                        <li><a href="index.php">HOME</a></li>
                                        <li><a href="admin/login.php">ADMIN</a></li>
                                        <li><a href="user/login.php">USER</a></li>
                                      
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>
</body>


